//walker freitas dos santos
//698774
//exercicio resolvido 01, pg 51, slide 06b


//Seja nossa Pilha, faça um método RECURSIVO que soma o conteúdo dos
//elementos contidos na mesma

int soma()
{
	int resp = 0;
	for(Celula i; i != null; i.prox())
	{
		res += i.elemento();
	}
	return resp;
}
